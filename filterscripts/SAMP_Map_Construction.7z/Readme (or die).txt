  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2018
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization in Notepad with monospaced font, as "Consolas".


------- Instructions:

Put the files on your GTA SA folder, open the "editor.exe" and click on "Load".

To learn how to use it (focused on singleplayer, but also usefull for SAMP), I recommend this tutorial:
https://forum.mixmods.com.br/f34-tutoriais/t50-1-sa-mp-map-construction-apresentacao
 
You can convert it to use on singleplayer using PAWN 2 IPL:
https://www.mixmods.com.br/2016/10/samp-map-editor-map-construction-pawn-2.html



Version: 23/07/2014
--------------------

Author: JernejL


====   MixMods.com.br         ====
====   fb.com/FamiliaMixMods  ====

